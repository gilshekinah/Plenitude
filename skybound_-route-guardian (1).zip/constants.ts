
import { BiomeType } from './types';

export const PROJECT_NAMES = [
  "SkyBound: Route Guardian",
  "AeroQuest: Jetstream",
  "Flight Path: Alpha Strike"
];

export const BIOME_DATA: Record<BiomeType, { color: string; bg: string }> = {
  [BiomeType.CITY]: { color: 'text-blue-400', bg: 'bg-blue-900/20' },
  [BiomeType.OCEAN]: { color: 'text-cyan-400', bg: 'bg-cyan-900/20' },
  [BiomeType.DESERT]: { color: 'text-orange-400', bg: 'bg-orange-900/20' },
  [BiomeType.JUNGLE]: { color: 'text-green-400', bg: 'bg-green-900/20' },
  [BiomeType.MOUNTAINS]: { color: 'text-slate-300', bg: 'bg-slate-800/20' },
  [BiomeType.ISLANDS]: { color: 'text-emerald-400', bg: 'bg-emerald-900/20' },
  [BiomeType.ARCTIC]: { color: 'text-white', bg: 'bg-slate-100/10' },
};

export const SAMPLE_OBSTACLES = [
  "Thunderstorm Cells",
  "Catastrophic Turbulence",
  "Enemy Drone Swarms",
  "Anti-Air Towers",
  "Volcanic Ash Clouds",
  "Rogue Interceptors",
  "Heat Seekers"
];
