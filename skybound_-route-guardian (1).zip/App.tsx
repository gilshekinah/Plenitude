
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import ProjectDocumentation from './components/ProjectDocumentation';
import FlightSetup from './components/FlightSetup';
import GamePreview from './components/GamePreview';
import { generateFlightLevels } from './services/aiService';
import { GameLevel } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'doc' | 'prototype'>('doc');
  const [isLoading, setIsLoading] = useState(false);
  const [levels, setLevels] = useState<GameLevel[] | null>(null);

  const handleGenerate = async (origin: string, dest: string) => {
    setIsLoading(true);
    const generatedLevels = await generateFlightLevels(origin, dest);
    setLevels(generatedLevels);
    setIsLoading(false);
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
      {activeTab === 'doc' ? (
        <ProjectDocumentation />
      ) : (
        <div className="space-y-8">
          {!levels ? (
            <div className="py-12">
              <FlightSetup onGenerate={handleGenerate} isLoading={isLoading} />
              
              <div className="mt-16 grid md:grid-cols-3 gap-8 opacity-70">
                <div className="text-center p-6">
                  <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4 text-xl">📍</div>
                  <h4 className="font-bold mb-2">Real Geography</h4>
                  <p className="text-sm text-slate-400">Levels adapt to mountains, oceans, and cities below the real route.</p>
                </div>
                <div className="text-center p-6">
                  <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4 text-xl">🔋</div>
                  <h4 className="font-bold mb-2">Offline Ready</h4>
                  <p className="text-sm text-slate-400">Assets are pre-fetched so you can play without internet at 35,000ft.</p>
                </div>
                <div className="text-center p-6">
                  <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4 text-xl">🎮</div>
                  <h4 className="font-bold mb-2">Casual Combat</h4>
                  <p className="text-sm text-slate-400">Easy-to-play mechanics designed for the cramped seating of an economy flight.</p>
                </div>
              </div>
            </div>
          ) : (
            <GamePreview levels={levels} onBack={() => setLevels(null)} />
          )}
        </div>
      )}
    </Layout>
  );
};

export default App;
