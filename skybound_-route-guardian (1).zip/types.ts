
export interface FlightRoute {
  origin: string;
  destination: string;
  originCoords: { lat: number; lng: number };
  destCoords: { lat: number; lng: number };
}

export interface GameLevel {
  id: number;
  name: string;
  description: string;
  biome: BiomeType;
  obstacles: string[];
  difficulty: number;
}

export enum BiomeType {
  CITY = 'Metropolis',
  OCEAN = 'Deep Atlantic',
  DESERT = 'Sahara Sands',
  JUNGLE = 'Amazonian Canopy',
  MOUNTAINS = 'Himalayan Peaks',
  ISLANDS = 'Pacific Archipelago',
  ARCTIC = 'Polar Tundra'
}

export interface ProjectDocs {
  names: string[];
  narrative: string;
  architecture: string;
  techStack: string[];
  monetization: string;
  roadmap: string[];
}
