
import { GoogleGenAI, Type } from "@google/genai";
import { GameLevel, BiomeType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateFlightLevels = async (origin: string, destination: string): Promise<GameLevel[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Create 10 game levels for a flight from ${origin} to ${destination}. 
      Level 1 must be Takeoff. Level 10 must be Landing. 
      The mid-levels should vary based on realistic geography for this route.
      Available Biomes: Metropolis, Deep Atlantic, Sahara Sands, Amazonian Canopy, Himalayan Peaks, Pacific Archipelago, Polar Tundra.
      Return exactly 10 levels.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.INTEGER },
              name: { type: Type.STRING },
              description: { type: Type.STRING },
              biome: { type: Type.STRING, description: "One of the provided Biome names" },
              obstacles: { type: Type.ARRAY, items: { type: Type.STRING } },
              difficulty: { type: Type.INTEGER, description: "1 to 10" }
            },
            required: ["id", "name", "description", "biome", "obstacles", "difficulty"]
          }
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("AI Generation failed, using fallback levels", error);
    return Array.from({ length: 10 }, (_, i) => ({
      id: i + 1,
      name: `Sector ${i + 1}`,
      description: `Exploring the vast sky between ${origin} and ${destination}`,
      biome: BiomeType.OCEAN,
      obstacles: ["Turbulence", "Rogue Drones"],
      difficulty: i + 1
    }));
  }
};
