
import React, { useState } from 'react';

interface FlightSetupProps {
  onGenerate: (origin: string, dest: string) => void;
  isLoading: boolean;
}

const FlightSetup: React.FC<FlightSetupProps> = ({ onGenerate, isLoading }) => {
  const [origin, setOrigin] = useState('New York (JFK)');
  const [dest, setDest] = useState('London (LHR)');

  return (
    <div className="max-w-xl mx-auto bg-slate-900 border border-slate-800 p-8 rounded-3xl shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="text-center mb-8">
        <div className="inline-block p-4 bg-blue-600/20 rounded-2xl text-blue-400 mb-4">
          <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
            <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" />
          </svg>
        </div>
        <h2 className="text-3xl font-bold text-white">Plan Your Mission</h2>
        <p className="text-slate-400">Enter your flight path to generate your unique game world.</p>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); onGenerate(origin, dest); }} className="space-y-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-bold text-slate-400 uppercase tracking-wider mb-2">Origin Airport</label>
            <input 
              type="text" 
              value={origin}
              onChange={(e) => setOrigin(e.target.value)}
              placeholder="e.g. Sao Paulo (GRU)"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>
          
          <div className="flex justify-center -my-2">
            <div className="w-10 h-10 bg-slate-800 border border-slate-700 rounded-full flex items-center justify-center text-slate-500 rotate-90">
              ⇄
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-400 uppercase tracking-wider mb-2">Destination Airport</label>
            <input 
              type="text" 
              value={dest}
              onChange={(e) => setDest(e.target.value)}
              placeholder="e.g. Lisbon (LIS)"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>
        </div>

        <button 
          disabled={isLoading}
          type="submit"
          className={`w-full py-4 rounded-xl font-bold text-lg transition-all flex items-center justify-center gap-3 ${isLoading ? 'bg-slate-800 text-slate-500 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-500 text-white shadow-xl shadow-blue-500/20'}`}
        >
          {isLoading ? (
            <>
              <div className="w-5 h-5 border-2 border-slate-600 border-t-white rounded-full animate-spin" />
              Scanning Real-world Terrain...
            </>
          ) : (
            <>Generate Game World</>
          )}
        </button>
      </form>
    </div>
  );
};

export default FlightSetup;
