
import React, { useEffect, useRef, useState } from 'react';
import { GameLevel, BiomeType } from '../types';
import { BIOME_DATA } from '../constants';

interface GamePreviewProps {
  levels: GameLevel[];
  onBack: () => void;
}

interface WeatherParticle {
  x: number;
  y: number;
  vx: number; 
  vy: number;
  size: number;
  opacity: number;
  jitter: number;
  length: number;
}

const GamePreview: React.FC<GamePreviewProps> = ({ levels, onBack }) => {
  const [currentLevelIdx, setCurrentLevelIdx] = useState(0);
  const [isMuted, setIsMuted] = useState(true);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Audio Refs
  const audioCtxRef = useRef<AudioContext | null>(null);
  const noiseNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const filterNodeRef = useRef<BiquadFilterNode | null>(null);

  const currentLevel = levels[currentLevelIdx];
  const biomeStyle = BIOME_DATA[currentLevel.biome as BiomeType] || BIOME_DATA[BiomeType.OCEAN];

  // Procedural Sound Synthesis
  const initAudio = () => {
    if (audioCtxRef.current) return;

    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = new AudioContextClass();
    audioCtxRef.current = ctx;

    // Create White Noise Buffer
    const bufferSize = 2 * ctx.sampleRate;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 1000;
    filter.Q.value = 1;

    const gain = ctx.createGain();
    gain.gain.value = isMuted ? 0 : 0.1;

    whiteNoise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    whiteNoise.start();

    noiseNodeRef.current = whiteNoise;
    filterNodeRef.current = filter;
    gainNodeRef.current = gain;
  };

  const updateAmbientSound = (biome: string, difficulty: number) => {
    if (!filterNodeRef.current || !gainNodeRef.current || !audioCtxRef.current) return;

    const ctx = audioCtxRef.current;
    const filter = filterNodeRef.current;
    const gain = gainNodeRef.current;

    const diffScale = 1 + (difficulty * 0.1);

    // Dynamic filtering based on weather
    switch (biome) {
      case BiomeType.ARCTIC:
        filter.type = 'lowpass';
        filter.frequency.setTargetAtTime(400 * diffScale, ctx.currentTime, 1);
        gain.gain.setTargetAtTime(isMuted ? 0 : 0.05 * diffScale, ctx.currentTime, 1);
        break;
      case BiomeType.JUNGLE:
      case BiomeType.OCEAN:
        // Rain Sound (High Pass + Low Pass effect)
        filter.type = 'bandpass';
        filter.frequency.setTargetAtTime(2500, ctx.currentTime, 1);
        gain.gain.setTargetAtTime(isMuted ? 0 : 0.08 * diffScale, ctx.currentTime, 1);
        break;
      case BiomeType.MOUNTAINS:
      case BiomeType.DESERT:
        // Howling Wind (Low Pass with resonance)
        filter.type = 'lowpass';
        filter.frequency.setTargetAtTime(800 * diffScale, ctx.currentTime, 1);
        filter.Q.setTargetAtTime(5, ctx.currentTime, 1);
        gain.gain.setTargetAtTime(isMuted ? 0 : 0.1 * diffScale, ctx.currentTime, 1);
        break;
      default:
        filter.type = 'lowpass';
        filter.frequency.setTargetAtTime(1000, ctx.currentTime, 1);
        gain.gain.setTargetAtTime(isMuted ? 0 : 0.03, ctx.currentTime, 1);
    }
  };

  useEffect(() => {
    if (!isMuted) {
      initAudio();
      updateAmbientSound(currentLevel.biome, currentLevel.difficulty);
    } else if (gainNodeRef.current && audioCtxRef.current) {
      gainNodeRef.current.gain.setTargetAtTime(0, audioCtxRef.current.currentTime, 0.5);
    }
  }, [currentLevel, isMuted]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: WeatherParticle[] = [];
    
    const getWeatherType = (biome: string) => {
      switch (biome) {
        case BiomeType.ARCTIC: return 'snow';
        case BiomeType.JUNGLE:
        case BiomeType.OCEAN: return 'rain';
        case BiomeType.CITY:
        case BiomeType.MOUNTAINS: return 'light-rain';
        default: return 'wind';
      }
    };

    const weatherType = getWeatherType(currentLevel.biome);
    const particleCount = 60 + (currentLevel.difficulty * 15);

    const initParticles = () => {
      particles = Array.from({ length: particleCount }, () => {
        const difficultyScale = 1 + (currentLevel.difficulty * 0.1);
        let vx = 0, vy = 0, length = 0, size = 1 + Math.random(), opacity = 0.2 + Math.random() * 0.4;

        if (weatherType === 'snow') {
          vy = 1 * difficultyScale;
          size = 1.5 + Math.random() * 2;
        } else if (weatherType === 'rain' || weatherType === 'light-rain') {
          const baseSpeed = weatherType === 'rain' ? 12 : 8;
          vy = baseSpeed * difficultyScale;
          length = (weatherType === 'rain' ? 15 : 8) + Math.random() * 10;
        } else {
          vx = (2 + Math.random() * 3) * difficultyScale;
          vy = (4 + Math.random() * 4) * difficultyScale;
          length = 20 + Math.random() * 40;
          opacity = 0.1 + Math.random() * 0.2;
          size = 0.5 + Math.random();
        }

        return { x: Math.random() * canvas.width, y: Math.random() * canvas.height, vx, vy, size, opacity, jitter: weatherType === 'snow' ? Math.random() * 2 : 0, length };
      });
    };

    const draw = () => {
      ctx.fillStyle = '#020617';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const gradient = ctx.createRadialGradient(canvas.width / 2, canvas.height / 2, 0, canvas.width / 2, canvas.height / 2, canvas.width);
      gradient.addColorStop(0, biomeStyle.bg.replace('bg-', '').replace('/20', '').split('-')[0] === 'slate' ? '#1e293b' : '#0f172a');
      gradient.addColorStop(1, '#020617');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        if (weatherType === 'snow') p.x += Math.sin(Date.now() / 500 + p.y / 50) * p.jitter;
        if (p.y > canvas.height || p.x > canvas.width) {
          p.y = -p.length - 20;
          p.x = Math.random() * canvas.width - (p.vx > 0 ? 100 : 0);
        }
        ctx.beginPath();
        if (weatherType === 'rain' || weatherType === 'light-rain') {
          ctx.strokeStyle = `rgba(186, 230, 253, ${p.opacity})`;
          ctx.lineWidth = p.size;
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x, p.y + p.length);
          ctx.stroke();
        } else if (weatherType === 'snow') {
          ctx.fillStyle = `rgba(255, 255, 255, ${p.opacity})`;
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        } else if (weatherType === 'wind') {
          const windGrad = ctx.createLinearGradient(p.x, p.y, p.x + p.vx * 2, p.y + p.vy * 2);
          windGrad.addColorStop(0, `rgba(255, 255, 255, ${p.opacity})`);
          windGrad.addColorStop(1, `rgba(255, 255, 255, 0)`);
          ctx.strokeStyle = windGrad;
          ctx.lineWidth = p.size;
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x + p.vx * 3, p.y + p.vy * 3);
          ctx.stroke();
        }
      });

      const time = Date.now() / 1000;
      const swayScale = weatherType === 'wind' ? 1.5 : 1;
      const shipY = canvas.height * 0.75 + Math.sin(time * 1.5) * 8 * swayScale;
      const shipX = canvas.width / 2 + Math.cos(time * 0.8) * 40 * swayScale;

      ctx.save();
      ctx.translate(shipX, shipY);
      const trailLength = 40 + (currentLevel.difficulty * 4);
      const trailGrad = ctx.createLinearGradient(0, 0, 0, trailLength);
      trailGrad.addColorStop(0, 'rgba(56, 189, 248, 0.8)');
      trailGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
      ctx.fillStyle = trailGrad;
      ctx.beginPath();
      ctx.moveTo(-8, 15);
      ctx.lineTo(8, 15);
      ctx.lineTo(0, trailLength + Math.random() * 15);
      ctx.fill();

      ctx.shadowBlur = 15;
      ctx.shadowColor = 'rgba(0,0,0,0.5)';
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.roundRect(-6, -35, 12, 60, 6);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(-35, 0);
      ctx.lineTo(35, 0);
      ctx.lineTo(5, -10);
      ctx.lineTo(-5, -10);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(-15, 20);
      ctx.lineTo(15, 20);
      ctx.lineTo(0, 10);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#cbd5e1';
      for(let i=0; i<4; i++) ctx.fillRect(-2, -25 + (i * 6), 4, 3);
      ctx.restore();

      animationFrameId = requestAnimationFrame(draw);
    };

    const resize = () => {
      if (canvas.parentElement) {
        canvas.width = canvas.parentElement.clientWidth;
        canvas.height = canvas.parentElement.clientHeight;
        initParticles();
      }
    };

    window.addEventListener('resize', resize);
    resize();
    draw();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', resize);
    };
  }, [currentLevelIdx, currentLevel]);

  return (
    <div className="grid lg:grid-cols-3 gap-6 h-[700px] animate-in slide-in-from-bottom-8 duration-500">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 overflow-y-auto space-y-3 custom-scrollbar">
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
          <svg className="w-5 h-5 text-blue-500" fill="currentColor" viewBox="0 0 24 24">
            <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" />
          </svg>
          Flight Manifest
        </h3>
        {levels.map((lvl, idx) => (
          <button
            key={lvl.id}
            onClick={() => setCurrentLevelIdx(idx)}
            className={`w-full p-4 rounded-2xl border transition-all flex items-center justify-between group ${
              currentLevelIdx === idx 
              ? 'bg-blue-600 border-blue-400 text-white shadow-xl shadow-blue-500/20 translate-x-1' 
              : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500 hover:bg-slate-700'
            }`}
          >
            <div className="flex flex-col items-start text-left">
              <span className={`text-[10px] uppercase font-bold ${currentLevelIdx === idx ? 'text-blue-100' : 'text-slate-500'}`}>
                Phase {lvl.id}
              </span>
              <span className="font-semibold text-sm truncate w-32">{lvl.name}</span>
            </div>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${currentLevelIdx === idx ? 'bg-white/20' : 'bg-slate-700'}`}>
              {idx < currentLevelIdx ? '✓' : idx === currentLevelIdx ? '▶' : lvl.difficulty}
            </div>
          </button>
        ))}
      </div>

      <div className="lg:col-span-2 relative bg-black rounded-3xl overflow-hidden shadow-2xl border-4 border-slate-800">
        <canvas ref={canvasRef} className="w-full h-full cursor-crosshair" />
        
        <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6">
          <div className="flex justify-between items-start">
            <div className="bg-slate-950/90 backdrop-blur-xl border border-slate-700 p-4 rounded-2xl w-72 animate-in fade-in slide-in-from-top-4 duration-700">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full animate-pulse ${biomeStyle.color.replace('text', 'bg')}`} />
                  <span className={`text-[10px] font-bold uppercase tracking-widest ${biomeStyle.color}`}>{currentLevel.biome}</span>
                </div>
                <div className="flex items-center gap-2">
                   <button 
                    onClick={() => setIsMuted(!isMuted)} 
                    className="pointer-events-auto text-slate-400 hover:text-white transition-colors"
                  >
                    {isMuted ? (
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" /></svg>
                    ) : (
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                    )}
                  </button>
                  <span className="text-[10px] text-slate-500 font-mono">ALT: 34,000 FT</span>
                </div>
              </div>
              <h4 className="text-lg font-bold text-white mb-1 leading-tight">{currentLevel.name}</h4>
              <p className="text-[11px] text-slate-400 leading-snug">{currentLevel.description}</p>
            </div>

            <div className="space-y-2">
                <div className="bg-red-600/20 backdrop-blur border border-red-500/50 p-2 rounded-lg text-red-400 text-[10px] font-bold uppercase tracking-widest flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-ping" />
                  Signal Anomaly: Phase {currentLevel.id}
                </div>
            </div>
          </div>

          <div className="flex justify-between items-end gap-4">
            <div className="bg-slate-950/90 backdrop-blur-xl border border-slate-700 p-4 rounded-2xl flex-1 max-w-sm">
              <h5 className="text-[9px] text-slate-500 font-bold uppercase mb-2 tracking-widest">Active Flight Threats</h5>
              <div className="flex flex-wrap gap-2">
                {currentLevel.obstacles.map((obs, i) => (
                  <span key={i} className="bg-slate-800 px-2 py-1 rounded text-[9px] font-bold text-slate-300 border border-slate-700 uppercase">
                    {obs}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex flex-col items-end gap-3">
              <button 
                onClick={onBack}
                className="pointer-events-auto bg-slate-900/80 hover:bg-slate-800 text-white px-5 py-2 rounded-xl text-xs font-bold border border-slate-700 transition-all flex items-center gap-2 backdrop-blur-md"
              >
                Abort Flight
              </button>
              <div className="bg-slate-950/90 backdrop-blur-xl border border-slate-700 p-4 rounded-2xl flex gap-6 shadow-2xl">
                <div className="text-center">
                  <div className="text-[9px] text-slate-500 font-bold uppercase tracking-tighter">Integrity</div>
                  <div className="text-lg font-bold text-blue-400">100%</div>
                </div>
                <div className="text-center">
                  <div className="text-[9px] text-slate-500 font-bold uppercase tracking-tighter">X-Points</div>
                  <div className="text-lg font-bold text-white">{(currentLevelIdx * 1250).toLocaleString()}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GamePreview;
