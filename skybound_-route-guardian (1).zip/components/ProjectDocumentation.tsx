
import React from 'react';

const Section: React.FC<{ title: string; children: React.ReactNode; icon: React.ReactNode }> = ({ title, children, icon }) => (
  <section className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 mb-8 hover:border-slate-700 transition-colors">
    <div className="flex items-center gap-3 mb-6">
      <div className="p-2 bg-blue-500/10 rounded-lg text-blue-400">
        {icon}
      </div>
      <h2 className="text-2xl font-bold text-slate-100">{title}</h2>
    </div>
    {children}
  </section>
);

const ProjectDocumentation: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-4xl font-extrabold mb-4">Mobile Game Concept & Technical Specs</h1>
        <p className="text-slate-400 text-lg leading-relaxed">
          Transforming standard air travel into a gamified odyssey using geolocation and procedural level generation.
        </p>
      </div>

      <Section title="Game Names & Narrative" icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>}>
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="font-semibold text-blue-400 mb-2 uppercase tracking-wider text-sm">Suggested Names</h3>
            <ul className="space-y-2 text-slate-300">
              <li className="bg-slate-800/40 p-3 rounded-lg border border-slate-700 flex items-center gap-2">
                <span className="text-blue-500">01.</span> SkyBound: Route Guardian
              </li>
              <li className="bg-slate-800/40 p-3 rounded-lg border border-slate-700 flex items-center gap-2">
                <span className="text-blue-500">02.</span> AeroQuest: Jetstream
              </li>
              <li className="bg-slate-800/40 p-3 rounded-lg border border-slate-700 flex items-center gap-2">
                <span className="text-blue-500">03.</span> Flight Path: Alpha Strike
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-blue-400 mb-2 uppercase tracking-wider text-sm">Story Concept</h3>
            <p className="text-slate-400 leading-relaxed italic">
              "In the near future, the upper atmosphere has become infested with 'Slipstream Anomalies'—phantom entities and rogue automated drones. As a Sky Guardian pilot, your actual commercial flight follows a path that needs protection. Your mission is to secure the route for the civilian aircraft following behind you."
            </p>
          </div>
        </div>
      </Section>

      <Section title="Phase Progression (10 Phases)" icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>}>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {[
            "Takeoff Clearance", "Cloud Ascent", "Sector Alpha", "Sector Beta", "Midpoint Crisis",
            "Sector Gamma", "Sector Delta", "Descent Vector", "Holding Pattern", "Terminal Arrival"
          ].map((phase, idx) => (
            <div key={idx} className="bg-slate-900 p-4 rounded-xl border border-slate-800 text-center flex flex-col items-center">
              <span className="text-xs text-slate-500 font-mono mb-1">LVL {idx + 1}</span>
              <span className="text-sm font-semibold text-slate-300">{phase}</span>
            </div>
          ))}
        </div>
        <p className="mt-6 text-slate-400 text-sm">
          Levels are dynamically generated based on the actual geography beneath the flight path. For instance, a flight over the Atlantic will feature ocean-based biomes, while a cross-continental flight will switch between deserts, forests, and mountains.
        </p>
      </Section>

      <Section title="Technical Architecture" icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" /></svg>}>
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="bg-slate-800/30 p-4 rounded-xl border border-slate-700">
              <h4 className="font-bold text-slate-200 mb-2">Engine & Client</h4>
              <p className="text-slate-400 text-sm">
                <strong>Unity (C#):</strong> Industry standard for high-performance mobile gaming. Lightweight rendering for mid-range devices.<br/>
                <strong>Addressables:</strong> For downloading map assets/biomes based on the route before departure.
              </p>
            </div>
            <div className="bg-slate-800/30 p-4 rounded-xl border border-slate-700">
              <h4 className="font-bold text-slate-200 mb-2">Data & Geolocation</h4>
              <p className="text-slate-400 text-sm">
                <strong>Google Maps API:</strong> Fetching elevation and biome data for route coordinates.<br/>
                <strong>FlightAware / OpenSky API:</strong> For obtaining real flight vectors and estimated paths.
              </p>
            </div>
          </div>
          <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 mono text-xs text-blue-300 overflow-x-auto">
            <div className="mb-2 text-slate-500">// Pseudo-Architectural Flow</div>
            <div>[USER INPUT] - Origin / Dest</div>
            <div>&nbsp;&nbsp;&nbsp;↓</div>
            <div>[BACKEND] - Calculate GCD (Great Circle Distance)</div>
            <div>&nbsp;&nbsp;&nbsp;↓</div>
            <div>[API] - Generate 10 GPS Waypoints</div>
            <div>&nbsp;&nbsp;&nbsp;↓</div>
            <div>[ASSET PRE-FETCH] - Download Biomes (WiFi only)</div>
            <div>&nbsp;&nbsp;&nbsp;↓</div>
            <div>[OFFLINE SESSION] - Local Persistence (SQLite)</div>
            <div>&nbsp;&nbsp;&nbsp;↓</div>
            <div>[GAME ENGINE] - Procedural Level Generation</div>
          </div>
        </div>
      </Section>

      <Section title="Monetization Strategy" icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-blue-600/10 p-5 rounded-xl border border-blue-500/30">
            <h4 className="font-bold text-blue-400 mb-2">Ad-Supported</h4>
            <p className="text-slate-400 text-xs leading-relaxed">Rewarded videos for 'Second Life' during challenging phases. Interstitials between levels (only if online).</p>
          </div>
          <div className="bg-cyan-600/10 p-5 rounded-xl border border-cyan-500/30">
            <h4 className="font-bold text-cyan-400 mb-2">Cosmetic Shop</h4>
            <p className="text-slate-400 text-xs leading-relaxed">Skins for aircraft (Airliner, Fighter Jet, Steampunk Blimp). Customizable exhaust trails and laser colors.</p>
          </div>
          <div className="bg-emerald-600/10 p-5 rounded-xl border border-emerald-500/30">
            <h4 className="font-bold text-emerald-400 mb-2">Premium Pass</h4>
            <p className="text-slate-400 text-xs leading-relaxed">One-time purchase for ad-free experience and access to 'Hyper-Sonic' special route mode.</p>
          </div>
        </div>
      </Section>

      <div className="bg-gradient-to-r from-blue-600 to-cyan-500 p-8 rounded-3xl text-white shadow-2xl shadow-blue-500/20">
        <h3 className="text-2xl font-bold mb-4">Development Roadmap</h3>
        <div className="space-y-4">
          <div className="flex items-start gap-4">
            <div className="bg-white/20 p-2 rounded-lg font-bold">M1</div>
            <div>
              <p className="font-bold">MVP Phase (Week 1-4)</p>
              <p className="text-blue-100 text-sm">Core flight mechanics, GPS input parsing, basic Top-down shooter engine.</p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <div className="bg-white/20 p-2 rounded-lg font-bold">M2</div>
            <div>
              <p className="font-bold">Content Expansion (Week 5-10)</p>
              <p className="text-blue-100 text-sm">Implementation of 7 Biomes, boss battles at phases 5 and 10, weapon system.</p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <div className="bg-white/20 p-2 rounded-lg font-bold">M3</div>
            <div>
              <p className="font-bold">Polishing & Release (Week 11-14)</p>
              <p className="text-blue-100 text-sm">Sound design, performance optimization for Android, Google Play Store testing.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDocumentation;
