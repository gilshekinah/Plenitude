
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: 'doc' | 'prototype';
  setActiveTab: (tab: 'doc' | 'prototype') => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab }) => {
  return (
    <div className="min-h-screen bg-slate-950 flex flex-col">
      <header className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-800 p-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/20">
              <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" />
              </svg>
            </div>
            <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
              SkyBound Project Dashboard
            </h1>
          </div>
          
          <nav className="flex bg-slate-900 p-1 rounded-full border border-slate-800">
            <button 
              onClick={() => setActiveTab('doc')}
              className={`px-6 py-2 rounded-full text-sm font-semibold transition-all ${activeTab === 'doc' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Project Documentation
            </button>
            <button 
              onClick={() => setActiveTab('prototype')}
              className={`px-6 py-2 rounded-full text-sm font-semibold transition-all ${activeTab === 'prototype' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Interactive Prototype
            </button>
          </nav>
        </div>
      </header>
      
      <main className="flex-1 w-full max-w-7xl mx-auto p-4 md:p-8">
        {children}
      </main>

      <footer className="border-t border-slate-900 p-8 text-center text-slate-500 text-sm">
        <p>© 2024 SkyBound Gaming Architecture Proposal. Built with React + Gemini AI.</p>
      </footer>
    </div>
  );
};

export default Layout;
